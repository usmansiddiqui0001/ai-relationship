
export interface SelectOption {
  value: string;
  label: string;
  emoji: string;
}
