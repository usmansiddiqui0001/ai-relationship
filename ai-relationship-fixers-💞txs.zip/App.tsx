
import React, { useState, useCallback } from 'react';
import { generateMessage } from './services/geminiService';
import { RELATIONSHIP_OPTIONS, MOOD_OPTIONS, MESSAGE_TYPE_OPTIONS } from './constants';
import CustomSelect from './components/CustomSelect';

const FilledHeartIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
    </svg>
);

const App: React.FC = () => {
    const [relationship, setRelationship] = useState<string>('Girlfriend');
    const [mood, setMood] = useState<string>('Angry');
    const [mistake, setMistake] = useState<string>('');
    const [messageType, setMessageType] = useState<string>('Apology');
    const [generatedMessage, setGeneratedMessage] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleClear = useCallback(() => {
        setRelationship('Girlfriend');
        setMood('Angry');
        setMistake('');
        setMessageType('Apology');
        setGeneratedMessage('');
        setError(null);
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (isLoading) return;
        
        if (!mistake.trim()) {
            setError("Please describe what happened.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setGeneratedMessage('');

        try {
            const message = await generateMessage({ relationship, mood, mistake, messageType });
            setGeneratedMessage(message);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unexpected error occurred.';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="min-h-screen flex items-center justify-center p-4 font-sans">
            <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl shadow-pink-200/50 p-6 sm:p-8 space-y-6">
                <h1 className="text-center text-3xl font-bold text-[#A94064]">AI Relationship Fixer</h1>

                <form onSubmit={handleSubmit} className="space-y-5">
                    <CustomSelect
                        id="relationship"
                        label="Who is this message for?"
                        value={relationship}
                        options={RELATIONSHIP_OPTIONS}
                        onChange={(e) => setRelationship(e.target.value)}
                    />

                    <CustomSelect
                        id="mood"
                        label="What's their current mood?"
                        value={mood}
                        options={MOOD_OPTIONS}
                        onChange={(e) => setMood(e.target.value)}
                    />

                    <div>
                        <label htmlFor="mistake" className="block text-sm font-medium text-gray-700 mb-2">
                            What happened? (Your mistake or the situation)
                        </label>
                        <textarea
                            id="mistake"
                            value={mistake}
                            onChange={(e) => setMistake(e.target.value)}
                            placeholder="e.g. I forgot our anniversary"
                            className="w-full bg-[#FFF8F9] border border-pink-200 text-gray-900 rounded-xl focus:ring-pink-400 focus:border-pink-400 block p-3 transition"
                            rows={3}
                        />
                    </div>
                    
                    <CustomSelect
                        id="messageType"
                        label="What kind of message do you need?"
                        value={messageType}
                        options={MESSAGE_TYPE_OPTIONS}
                        onChange={(e) => setMessageType(e.target.value)}
                    />

                    <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full flex items-center justify-center gap-2 bg-[#E58A9A] hover:bg-[#D4798A] text-white font-bold py-3 px-4 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 disabled:bg-pink-300 disabled:cursor-not-allowed"
                        >
                            {isLoading ? (
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                            ) : (
                                <FilledHeartIcon />
                            )}
                            {isLoading ? 'Creating...' : 'Create My Message'}
                        </button>
                        <button
                            type="button"
                            onClick={handleClear}
                            className="w-full border border-[#E58A9A] text-[#E58A9A] font-bold py-3 px-4 rounded-xl hover:bg-[#FFF8F9] transition-all duration-200"
                        >
                            Clear
                        </button>
                    </div>
                </form>

                {error && (
                    <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-r-lg" role="alert">
                        <p className="font-bold">Error</p>
                        <p>{error}</p>
                    </div>
                )}
                
                {generatedMessage && !isLoading && (
                    <div className="bg-[#FFF8F9] p-5 rounded-xl border border-pink-200 mt-6 animate-[fadeIn_0.5s_ease-in-out]">
                        <p className="text-gray-800 whitespace-pre-wrap leading-relaxed">{generatedMessage}</p>
                    </div>
                )}

                <p className="text-center text-xs text-gray-500 pt-4">
                    Powered by Gemini AI. Handle with care, speak from the heart.
                </p>
            </div>
        </div>
    );
};

export default App;
