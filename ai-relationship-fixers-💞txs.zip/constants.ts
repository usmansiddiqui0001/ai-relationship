
import type { SelectOption } from './types';

export const RELATIONSHIP_OPTIONS: SelectOption[] = [
  { value: 'Girlfriend', label: 'Girlfriend', emoji: '👩‍❤️‍👨' },
  { value: 'Boyfriend', label: 'Boyfriend', emoji: '👨‍❤️‍👩' },
  { value: 'Wife', label: 'Wife', emoji: '👰‍♀️' },
  { value: 'Husband', label: 'Husband', emoji: '🤵‍♂️' },
  { value: 'Partner', label: 'Partner', emoji: '💖' },
  { value: 'Friend', label: 'Friend', emoji: '😊' },
];

export const MOOD_OPTIONS: SelectOption[] = [
  { value: 'Angry', label: 'Angry', emoji: '😟' },
  { value: 'Sad', label: 'Sad', emoji: '😢' },
  { value: 'Disappointed', label: 'Disappointed', emoji: '😔' },
  { value: 'Upset', label: 'Upset', emoji: '😒' },
  { value: 'Hurt', label: 'Hurt', emoji: '💔' },
];

export const MESSAGE_TYPE_OPTIONS: SelectOption[] = [
  { value: 'Apology', label: 'Apology', emoji: '💔' },
  { value: 'Reconciliation', label: 'Reconciliation', emoji: '❤️‍🩹' },
  { value: 'Explanation', label: 'Explanation', emoji: '💬' },
  { value: 'Make them smile', label: 'Make them smile', emoji: '🥰' },
];
