
import React from 'react';
import type { SelectOption } from '../types';

interface CustomSelectProps {
  id: string;
  label: string;
  value: string;
  options: SelectOption[];
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const ChevronDownIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
  </svg>
);

const CustomSelect: React.FC<CustomSelectProps> = ({ id, label, value, options, onChange }) => {
  const selectedOption = options.find(option => option.value === value);

  return (
    <div className="w-full">
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-2">
        {label}
      </label>
      <div className="relative">
        {selectedOption?.emoji && (
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="text-xl">{selectedOption.emoji}</span>
            </div>
        )}
        <select
          id={id}
          value={value}
          onChange={onChange}
          className="appearance-none font-semibold w-full bg-[#FFF8F9] border border-pink-200 text-gray-900 rounded-xl focus:ring-pink-400 focus:border-pink-400 block py-3 pl-12 pr-10 transition"
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-700">
          <ChevronDownIcon />
        </div>
      </div>
    </div>
  );
};

export default CustomSelect;
