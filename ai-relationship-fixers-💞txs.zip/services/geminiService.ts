
import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY;
if (!apiKey) {
    console.error("API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || '' });

interface MessageParams {
    relationship: string;
    mood: string;
    mistake: string;
    messageType: string;
}

export const generateMessage = async ({
    relationship,
    mood,
    mistake,
    messageType,
}: MessageParams): Promise<string> => {
    
    if (!apiKey) {
        return "API Key not configured. Please set the API_KEY environment variable.";
    }

    const model = 'gemini-2.5-flash';

    const prompt = `You are a warm, emotionally intelligent AI Relationship Advisor.
Your task is to generate a heartfelt, romantic message based on the user’s inputs.
Use a natural mix of Hindi and English (Hinglish).
Express deep emotional understanding.
Make the partner feel heard, valued, and loved.
Output only the final message in a human tone. Do not add any extra text, titles, or introductions like "Here is the message:".

---
USER INPUTS:
- Relationship: ${relationship}
- Partner's Mood: ${mood}
- The Mistake/Situation: ${mistake}
- Desired Message Type: ${messageType}
---

Generate the message now.`;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating message with Gemini API:", error);
        if (error instanceof Error) {
            return `Sorry, I couldn't generate a message right now. Error: ${error.message}`;
        }
        return "An unknown error occurred while generating the message.";
    }
};
